"use server";

import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

export async function submitContactMessage(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim();
  const message = String(formData.get("message") ?? "").trim();

  if (!name || !email || !message) {
    redirect("/contact?status=error");
  }

  await prisma.contactMessage.create({ data: { name, email, message } });
  redirect("/contact?status=success");
}
