import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { submitContactMessage } from "./actions";

export const metadata = { title: "Contact" };

export default async function ContactPage({
  searchParams
}: {
  searchParams: { status?: string };
}) {
  const contact = await prisma.contactInfo.findUnique({ where: { id: "contact" } });

  return (
    <>
      <Header />
      <section className="bg-ivory py-20">
        <div className="mx-auto grid max-w-6xl gap-16 px-8 md:grid-cols-2">
          <div>
            <h1 className="mb-6 font-serif text-4xl">Visit the Showroom</h1>
            <dl className="grid grid-cols-[auto_1fr] gap-x-5 gap-y-3 text-sm">
              <dt className="text-black/50">Phone</dt><dd>{contact?.phone}</dd>
              <dt className="text-black/50">Email</dt><dd>{contact?.email}</dd>
              <dt className="text-black/50">Address</dt><dd>{contact?.address}</dd>
              <dt className="text-black/50">Hours</dt><dd>{contact?.hours}</dd>
            </dl>
            {contact?.mapEmbedUrl && (
              <div className="mt-8 aspect-video w-full border border-black/10">
                <iframe src={contact.mapEmbedUrl} className="h-full w-full" loading="lazy" />
              </div>
            )}
          </div>

          <form action={submitContactMessage} className="flex flex-col gap-4">
            <h2 className="mb-1 font-serif text-xl">Send an inquiry</h2>
            {searchParams.status === "success" && (
              <p className="bg-green-50 px-4 py-3 text-sm text-green-800">
                Message sent — thank you. We&apos;ll be in touch shortly.
              </p>
            )}
            {searchParams.status === "error" && (
              <p className="bg-red-50 px-4 py-3 text-sm text-red-800">
                Please fill in every field before sending.
              </p>
            )}
            <input name="name" placeholder="Name" required className="border-b border-black/20 bg-transparent px-1 py-3" />
            <input name="email" type="email" placeholder="Email" required className="border-b border-black/20 bg-transparent px-1 py-3" />
            <textarea
              name="message"
              placeholder="Tell us what you're looking for"
              required
              className="min-h-[110px] border-b border-black/20 bg-transparent px-1 py-3"
            />
            <button className="mt-2 self-start border border-bronze bg-bronze px-8 py-3.5 text-sm text-[#181410]">
              Send Message
            </button>
          </form>
        </div>
      </section>
      <Footer />
    </>
  );
}
