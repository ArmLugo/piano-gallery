import Image from "next/image";
import Link from "next/link";
import { Fragment } from "react";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { formatSpecs } from "@/lib/utils";
import type { Metadata } from "next";

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await prisma.product.findUnique({ where: { slug: params.slug } });
  if (!product) return {};
  return {
    title: `${product.brand} ${product.model}`,
    description: product.description,
    openGraph: { title: `${product.brand} ${product.model}`, description: product.description }
  };
}

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: { images: { orderBy: { order: "asc" } } }
  });
  if (!product) notFound();

  const specs = formatSpecs(product.specs);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `${product.brand} ${product.model}`,
    description: product.description,
    brand: product.brand,
    offers: {
      "@type": "Offer",
      price: product.priceValue ?? undefined,
      priceCurrency: "USD",
      availability:
        product.availability === "In Stock"
          ? "https://schema.org/InStock"
          : "https://schema.org/OutOfStock"
    }
  };

  return (
    <>
      <Header />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-8">
          <div className="grid gap-16 md:grid-cols-2">
            <div>
              <div className="relative aspect-[5/4] bg-ivory">
                {product.images[0] ? (
                  <Image
                    src={product.images[0].url}
                    alt={product.images[0].alt ?? product.model}
                    fill
                    className="object-cover"
                    priority
                  />
                ) : (
                  <div className="flex h-full items-center justify-center text-black/30">No photo</div>
                )}
              </div>
              {product.images.length > 1 && (
                <div className="mt-3 grid grid-cols-4 gap-3">
                  {product.images.slice(1).map((img) => (
                    <div key={img.id} className="relative aspect-square bg-ivory">
                      <Image src={img.url} alt={img.alt ?? product.model} fill className="object-cover" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <div className="mb-2 text-sm tracking-wider text-bronze">{product.brand.toUpperCase()}</div>
              <h1 className="mb-4 font-serif text-4xl">{product.model}</h1>
              <p className="mb-6 text-black/70">{product.description}</p>

              <dl className="mb-6 grid grid-cols-2 gap-y-3 text-sm">
                <dt className="text-black/50">Year</dt><dd>{product.year ?? "—"}</dd>
                <dt className="text-black/50">Dimensions</dt><dd>{product.dimensions ?? "—"}</dd>
                <dt className="text-black/50">Finish</dt><dd>{product.finish ?? "—"}</dd>
                <dt className="text-black/50">Condition</dt><dd>{product.condition ?? "—"}</dd>
                <dt className="text-black/50">Availability</dt><dd>{product.availability}</dd>
              </dl>

              {Object.keys(specs).length > 0 && (
                <div className="mb-8 border-t border-black/10 pt-5">
                  <h2 className="mb-3 font-serif text-xl">Technical Specifications</h2>
                  <dl className="grid grid-cols-2 gap-y-2 text-sm">
                    {Object.entries(specs).map(([k, v]) => (
                      <Fragment key={k}>
                        <dt className="text-black/50">{k}</dt>
                        <dd>{v}</dd>
                      </Fragment>
                    ))}
                  </dl>
                </div>
              )}

              <div className="flex items-center justify-between border-t border-black/10 pt-6">
                <span className="font-serif text-2xl">{product.price}</span>
                <Link href="/contact" className="border border-ink px-6 py-3 text-sm">
                  Contact About This Piano
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
