import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import type { Prisma } from "@prisma/client";

export const metadata = { title: "Pianos" };

export default async function PianosPage({
  searchParams
}: {
  searchParams: { type?: string; brand?: string; price?: string; color?: string; availability?: string };
}) {
  const where: Prisma.ProductWhereInput = {};
  if (searchParams.type) where.category = searchParams.type;
  if (searchParams.brand) where.brand = searchParams.brand;
  if (searchParams.color) where.color = searchParams.color;
  if (searchParams.availability) where.availability = searchParams.availability;
  if (searchParams.price) {
    const [min, max] = searchParams.price.split("-").map(Number);
    where.priceValue = { gte: min, ...(max ? { lte: max } : {}) };
  }

  const [products, brands, colors] = await Promise.all([
    prisma.product.findMany({ where, include: { images: true }, orderBy: { createdAt: "desc" } }),
    prisma.product.findMany({ distinct: ["brand"], select: { brand: true } }),
    prisma.product.findMany({ distinct: ["color"], select: { color: true } })
  ]);

  return (
    <>
      <Header />
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-8">
          <h1 className="mb-12 font-serif text-4xl">Pianos & Grand Pianos</h1>
          <form className="mb-12 flex flex-wrap gap-4 border-b border-black/10 pb-8 text-sm">
            <select name="type" defaultValue={searchParams.type ?? ""} className="border border-black/15 px-3 py-2">
              <option value="">All Types</option>
              <option value="grand">Grand Piano</option>
              <option value="upright">Upright Piano</option>
              <option value="digital">Digital Piano</option>
            </select>
            <select name="brand" defaultValue={searchParams.brand ?? ""} className="border border-black/15 px-3 py-2">
              <option value="">All Brands</option>
              {brands.map((b) => (
                <option key={b.brand} value={b.brand}>{b.brand}</option>
              ))}
            </select>
            <select name="color" defaultValue={searchParams.color ?? ""} className="border border-black/15 px-3 py-2">
              <option value="">Any Color</option>
              {colors.filter((c) => c.color).map((c) => (
                <option key={c.color} value={c.color!}>{c.color}</option>
              ))}
            </select>
            <select name="price" defaultValue={searchParams.price ?? ""} className="border border-black/15 px-3 py-2">
              <option value="">Any Price</option>
              <option value="0-8000">Under $8,000</option>
              <option value="8000-25000">$8,000 – $25,000</option>
              <option value="25000-">$25,000+</option>
            </select>
            <select name="availability" defaultValue={searchParams.availability ?? ""} className="border border-black/15 px-3 py-2">
              <option value="">Any Availability</option>
              <option value="In Stock">In Stock</option>
              <option value="On Order">On Order</option>
              <option value="Sold">Sold</option>
            </select>
            <button className="border border-ink px-5 py-2">Filter</button>
          </form>

          {products.length === 0 ? (
            <p className="text-sm text-black/50">No pianos match these filters yet.</p>
          ) : (
            <div className="grid grid-cols-1 gap-px border border-black/10 bg-black/10 md:grid-cols-3">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>
      <Footer />
    </>
  );
}
