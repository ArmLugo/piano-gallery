import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = { title: "Services" };

export default async function ServicesPage() {
  const services = await prisma.service.findMany({ orderBy: { order: "asc" } });

  return (
    <>
      <Header />
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-8">
          <h1 className="mb-12 font-serif text-4xl">Services</h1>
          <div className="grid gap-10 md:grid-cols-2">
            {services.map((service) => (
              <div key={service.id} className="border-t border-ink pt-6">
                <h2 className="mb-2 font-serif text-2xl">{service.title}</h2>
                <p className="text-black/70">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
