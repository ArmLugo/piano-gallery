import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";

export const metadata = { title: "Grand Pianos" };

export default async function GrandPianosPage() {
  const products = await prisma.product.findMany({
    where: { category: "grand" },
    include: { images: true },
    orderBy: { createdAt: "desc" }
  });

  return (
    <>
      <Header />
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-8">
          <h1 className="mb-4 font-serif text-4xl">Grand Pianos</h1>
          <p className="mb-12 max-w-[60ch] text-sm text-black/60">
            Our grand piano collection, spanning conservatory workhorses to hand-built European instruments.
          </p>
          <div className="grid grid-cols-1 gap-px border border-black/10 bg-black/10 md:grid-cols-3">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
