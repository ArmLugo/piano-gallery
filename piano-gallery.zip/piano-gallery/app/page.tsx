import Link from "next/link";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";

export default async function HomePage() {
  const [hero, featured, about, services, contact] = await Promise.all([
    prisma.heroContent.findUnique({ where: { id: "hero" } }),
    prisma.product.findMany({ where: { featured: true }, include: { images: true }, take: 6 }),
    prisma.aboutContent.findUnique({ where: { id: "about" } }),
    prisma.service.findMany({ orderBy: { order: "asc" }, take: 5 }),
    prisma.contactInfo.findUnique({ where: { id: "contact" } })
  ]);

  return (
    <>
      <Header />

      <section className="bg-[#1B1712] py-24">
        <div className="mx-auto grid max-w-6xl items-center gap-16 px-8 md:grid-cols-2">
          <div>
            <div className="mb-4 text-sm tracking-[0.2em] text-bronze-soft">PIANO GALLERY</div>
            <h1 className="mb-6 font-serif text-6xl leading-[1.04] text-paper">{hero?.title}</h1>
            <p className="mb-8 max-w-[46ch] text-[#D8D2C4]">{hero?.subtitle}</p>
            <div className="flex flex-wrap gap-4">
              <Link href="/pianos" className="border border-bronze bg-bronze px-8 py-3.5 text-sm text-[#181410]">
                {hero?.ctaPrimaryLabel ?? "Explore Collection"}
              </Link>
              <Link href="/contact" className="border border-white/40 px-8 py-3.5 text-sm text-paper">
                {hero?.ctaSecondaryLabel ?? "Contact Us"}
              </Link>
            </div>
          </div>
          <div className="relative aspect-[4/5] border border-white/15">
            {hero?.imageUrl ? (
              <Image src={hero.imageUrl} alt="Grand piano" fill className="object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-white/30">Hero image</div>
            )}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="mx-auto max-w-6xl px-8">
          <div className="mb-12 flex flex-wrap items-end justify-between gap-6">
            <h2 className="font-serif text-4xl">Featured Instruments</h2>
            <p className="max-w-[38ch] text-sm text-black/60">
              A rotating selection from our showroom floor, chosen for tone, condition and craftsmanship.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-px border border-black/10 bg-black/10 md:grid-cols-3">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-charcoal py-24 text-ivory">
        <div className="mx-auto grid max-w-6xl items-center gap-16 px-8 md:grid-cols-2">
          <div className="relative aspect-square border border-white/15">
            {about?.imageUrl ? (
              <Image src={about.imageUrl} alt="Showroom" fill className="object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-white/30">About image</div>
            )}
          </div>
          <div>
            <h2 className="mb-5 font-serif text-4xl text-paper">{about?.heading}</h2>
            <p className="mb-4 max-w-[52ch] text-[#C9C2B2]">{about?.paragraph1}</p>
            <p className="max-w-[52ch] text-[#C9C2B2]">{about?.paragraph2}</p>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="mx-auto max-w-6xl px-8">
          <h2 className="mb-12 font-serif text-4xl">Services</h2>
          <div className="grid grid-cols-2 gap-7 md:grid-cols-5">
            {services.map((service) => (
              <div key={service.id} className="border-t border-ink pt-5">
                <h3 className="mb-2 font-serif text-xl">{service.title}</h3>
                <p className="text-sm text-black/60">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-ivory py-24">
        <div className="mx-auto max-w-6xl px-8">
          <h2 className="mb-5 font-serif text-4xl">Visit the Showroom</h2>
          <p className="text-sm text-black/60">
            {contact?.address} · {contact?.phone} · {contact?.email}
          </p>
          <Link href="/contact" className="mt-6 inline-block border-b border-ink text-sm">
            Get in touch
          </Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
