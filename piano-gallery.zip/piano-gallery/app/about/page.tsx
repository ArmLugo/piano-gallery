import Image from "next/image";
import { prisma } from "@/lib/prisma";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = { title: "About Us" };

export default async function AboutPage() {
  const about = await prisma.aboutContent.findUnique({ where: { id: "about" } });

  return (
    <>
      <Header />
      <section className="py-20">
        <div className="mx-auto grid max-w-6xl items-center gap-16 px-8 md:grid-cols-2">
          <div className="relative aspect-square bg-ivory">
            {about?.imageUrl ? (
              <Image src={about.imageUrl} alt="Piano Gallery showroom" fill className="object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-black/30">Showroom image</div>
            )}
          </div>
          <div>
            <h1 className="mb-6 font-serif text-4xl">{about?.heading}</h1>
            <p className="mb-4 max-w-[58ch] text-black/70">{about?.paragraph1}</p>
            <p className="max-w-[58ch] text-black/70">{about?.paragraph2}</p>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
