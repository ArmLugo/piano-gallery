import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXTAUTH_URL?.replace(/\/$/, "") || "https://example.com";
  const products = await prisma.product.findMany({ select: { slug: true, updatedAt: true } });

  const staticRoutes = ["", "/pianos", "/grand-pianos", "/about", "/services", "/contact"].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date()
  }));

  const productRoutes = products.map((p) => ({
    url: `${base}/pianos/${p.slug}`,
    lastModified: p.updatedAt
  }));

  return [...staticRoutes, ...productRoutes];
}
