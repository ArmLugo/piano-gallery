import type { Metadata } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";

const displayFont = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-display"
});

const bodyFont = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body"
});

export const metadata: Metadata = {
  title: {
    default: "Piano Gallery — The Art of Music",
    template: "%s | Piano Gallery"
  },
  description:
    "Discover carefully selected pianos and grand pianos created for musicians who appreciate exceptional sound, craftsmanship and timeless design.",
  openGraph: {
    title: "Piano Gallery — The Art of Music",
    description:
      "Discover carefully selected pianos and grand pianos created for musicians who appreciate exceptional sound, craftsmanship and timeless design.",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${displayFont.variable} ${bodyFont.variable}`}>
      <body className="font-sans">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
