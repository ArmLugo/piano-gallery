import { prisma } from "@/lib/prisma";
import ImageUploader from "@/components/ImageUploader";
import { saveHero } from "../actions";

export default async function AdminHeroPage({ searchParams }: { searchParams: { saved?: string } }) {
  const hero = await prisma.heroContent.findUnique({ where: { id: "hero" } });

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Homepage Hero</h1>
      {searchParams.saved && <p className="mb-6 bg-green-50 px-4 py-2 text-sm text-green-800">Saved.</p>}
      <form action={saveHero} className="max-w-xl space-y-5">
        <div>
          <label className="mb-1 block text-xs text-black/50">Hero Image</label>
          <ImageUploader name="images" initial={hero?.imageUrl ? [{ url: hero.imageUrl, alt: "Hero" }] : []} />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Hero Title</label>
          <input name="title" defaultValue={hero?.title} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Hero Subtitle</label>
          <textarea name="subtitle" defaultValue={hero?.subtitle} required className="min-h-[90px] w-full border border-black/15 px-3 py-2" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-xs text-black/50">Primary Button Text</label>
            <input name="ctaPrimaryLabel" defaultValue={hero?.ctaPrimaryLabel} className="w-full border border-black/15 px-3 py-2" />
          </div>
          <div>
            <label className="mb-1 block text-xs text-black/50">Secondary Button Text</label>
            <input name="ctaSecondaryLabel" defaultValue={hero?.ctaSecondaryLabel} className="w-full border border-black/15 px-3 py-2" />
          </div>
        </div>
        <button className="border border-ink bg-ink px-8 py-3 text-sm text-paper">Save Changes</button>
      </form>
    </div>
  );
}
