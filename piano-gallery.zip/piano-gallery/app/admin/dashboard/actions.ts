"use server";

import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { slugify } from "@/lib/utils";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session) throw new Error("Unauthorized");
}

type UploadedImage = { url: string; alt: string };

export async function saveProduct(formData: FormData) {
  await requireAdmin();

  const id = String(formData.get("id") ?? "");
  const brand = String(formData.get("brand") ?? "").trim();
  const model = String(formData.get("model") ?? "").trim();
  const category = String(formData.get("category") ?? "grand");
  const price = String(formData.get("price") ?? "").trim();
  const priceValueRaw = String(formData.get("priceValue") ?? "").trim();
  const priceValue = priceValueRaw ? Number(priceValueRaw) : null;
  const year = String(formData.get("year") ?? "").trim();
  const dimensions = String(formData.get("dimensions") ?? "").trim() || null;
  const finish = String(formData.get("finish") ?? "").trim() || null;
  const color = String(formData.get("color") ?? "").trim() || null;
  const condition = String(formData.get("condition") ?? "").trim() || null;
  const availability = String(formData.get("availability") ?? "In Stock");
  const description = String(formData.get("description") ?? "").trim();
  const specsRaw = String(formData.get("specs") ?? "").trim();
  const featured = formData.get("featured") === "on";
  const imagesJson = String(formData.get("images") ?? "[]");
  const images: UploadedImage[] = JSON.parse(imagesJson || "[]");

  const slug = slugify(`${brand}-${model}`);

  const data = {
    slug,
    brand,
    model,
    category,
    price,
    priceValue,
    year: year ? Number(year) : null,
    dimensions,
    finish,
    color,
    condition,
    availability,
    description,
    specs: specsRaw || null,
    featured
  };

  const product = id
    ? await prisma.product.update({ where: { id }, data })
    : await prisma.product.create({ data });

  // Replace image set for simplicity
  await prisma.productImage.deleteMany({ where: { productId: product.id } });
  if (images.length > 0) {
    await prisma.productImage.createMany({
      data: images.map((img, i) => ({ productId: product.id, url: img.url, alt: img.alt, order: i }))
    });
  }

  revalidatePath("/");
  revalidatePath("/pianos");
  revalidatePath("/grand-pianos");
  revalidatePath(`/pianos/${slug}`);
  redirect("/admin/dashboard/products");
}

export async function deleteProduct(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id"));
  await prisma.product.delete({ where: { id } });
  revalidatePath("/pianos");
  revalidatePath("/grand-pianos");
  redirect("/admin/dashboard/products");
}

export async function saveHero(formData: FormData) {
  await requireAdmin();
  const title = String(formData.get("title") ?? "");
  const subtitle = String(formData.get("subtitle") ?? "");
  const ctaPrimaryLabel = String(formData.get("ctaPrimaryLabel") ?? "Explore Collection");
  const ctaSecondaryLabel = String(formData.get("ctaSecondaryLabel") ?? "Contact Us");
  const imagesJson = String(formData.get("images") ?? "[]");
  const images: UploadedImage[] = JSON.parse(imagesJson || "[]");
  const imageUrl = images[0]?.url ?? null;

  await prisma.heroContent.upsert({
    where: { id: "hero" },
    update: { title, subtitle, ctaPrimaryLabel, ctaSecondaryLabel, imageUrl },
    create: { id: "hero", title, subtitle, ctaPrimaryLabel, ctaSecondaryLabel, imageUrl }
  });
  revalidatePath("/");
  redirect("/admin/dashboard/hero?saved=1");
}

export async function saveAbout(formData: FormData) {
  await requireAdmin();
  const heading = String(formData.get("heading") ?? "");
  const paragraph1 = String(formData.get("paragraph1") ?? "");
  const paragraph2 = String(formData.get("paragraph2") ?? "");
  const imagesJson = String(formData.get("images") ?? "[]");
  const images: UploadedImage[] = JSON.parse(imagesJson || "[]");
  const imageUrl = images[0]?.url ?? null;

  await prisma.aboutContent.upsert({
    where: { id: "about" },
    update: { heading, paragraph1, paragraph2, imageUrl },
    create: { id: "about", heading, paragraph1, paragraph2, imageUrl }
  });
  revalidatePath("/");
  revalidatePath("/about");
  redirect("/admin/dashboard/about?saved=1");
}

export async function saveContact(formData: FormData) {
  await requireAdmin();
  const phone = String(formData.get("phone") ?? "");
  const email = String(formData.get("email") ?? "");
  const address = String(formData.get("address") ?? "");
  const hours = String(formData.get("hours") ?? "");
  const instagram = String(formData.get("instagram") ?? "") || null;
  const facebook = String(formData.get("facebook") ?? "") || null;
  const mapEmbedUrl = String(formData.get("mapEmbedUrl") ?? "") || null;

  await prisma.contactInfo.upsert({
    where: { id: "contact" },
    update: { phone, email, address, hours, instagram, facebook, mapEmbedUrl },
    create: { id: "contact", phone, email, address, hours, instagram, facebook, mapEmbedUrl }
  });
  revalidatePath("/");
  revalidatePath("/contact");
  redirect("/admin/dashboard/contact?saved=1");
}

export async function saveService(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const title = String(formData.get("title") ?? "");
  const description = String(formData.get("description") ?? "");
  const order = Number(formData.get("order") ?? 0);

  if (id) {
    await prisma.service.update({ where: { id }, data: { title, description, order } });
  } else {
    await prisma.service.create({ data: { title, description, order } });
  }
  revalidatePath("/");
  revalidatePath("/services");
  redirect("/admin/dashboard/services?saved=1");
}

export async function deleteService(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id"));
  await prisma.service.delete({ where: { id } });
  revalidatePath("/services");
  redirect("/admin/dashboard/services");
}

export async function saveNavItem(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const label = String(formData.get("label") ?? "");
  const href = String(formData.get("href") ?? "");
  const order = Number(formData.get("order") ?? 0);

  if (id) {
    await prisma.navItem.update({ where: { id }, data: { label, href, order } });
  } else {
    await prisma.navItem.create({ data: { label, href, order } });
  }
  revalidatePath("/");
  redirect("/admin/dashboard/navigation?saved=1");
}

export async function deleteNavItem(formData: FormData) {
  await requireAdmin();
  const id = String(formData.get("id"));
  await prisma.navItem.delete({ where: { id } });
  revalidatePath("/");
  redirect("/admin/dashboard/navigation");
}
