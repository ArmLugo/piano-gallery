import { prisma } from "@/lib/prisma";
import { saveService, deleteService } from "../actions";

export default async function AdminServicesPage({ searchParams }: { searchParams: { saved?: string } }) {
  const services = await prisma.service.findMany({ orderBy: { order: "asc" } });

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Services</h1>
      {searchParams.saved && <p className="mb-6 bg-green-50 px-4 py-2 text-sm text-green-800">Saved.</p>}

      <div className="mb-10 space-y-4">
        {services.map((s) => (
          <form key={s.id} action={saveService} className="flex items-end gap-3 border border-black/10 p-4">
            <input type="hidden" name="id" value={s.id} />
            <div className="w-20">
              <label className="mb-1 block text-xs text-black/50">Order</label>
              <input name="order" type="number" defaultValue={s.order} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <div className="w-48">
              <label className="mb-1 block text-xs text-black/50">Title</label>
              <input name="title" defaultValue={s.title} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <div className="flex-1">
              <label className="mb-1 block text-xs text-black/50">Description</label>
              <input name="description" defaultValue={s.description} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <button className="border border-ink px-4 py-1.5 text-sm">Save</button>
          </form>
        ))}
      </div>

      <div className="flex gap-3">
        {services.map((s) => (
          <form key={s.id} action={deleteService}>
            <input type="hidden" name="id" value={s.id} />
            <button className="text-xs text-red-700 underline">Delete "{s.title}"</button>
          </form>
        ))}
      </div>

      <h2 className="mb-4 mt-10 font-serif text-xl">Add a Service</h2>
      <form action={saveService} className="flex items-end gap-3 border border-black/10 p-4">
        <div className="w-20">
          <label className="mb-1 block text-xs text-black/50">Order</label>
          <input name="order" type="number" defaultValue={services.length} className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <div className="w-48">
          <label className="mb-1 block text-xs text-black/50">Title</label>
          <input name="title" required className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <div className="flex-1">
          <label className="mb-1 block text-xs text-black/50">Description</label>
          <input name="description" required className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <button className="border border-ink bg-ink px-4 py-1.5 text-sm text-paper">Add</button>
      </form>
    </div>
  );
}
