import { prisma } from "@/lib/prisma";
import ImageUploader from "@/components/ImageUploader";
import { saveAbout } from "../actions";

export default async function AdminAboutPage({ searchParams }: { searchParams: { saved?: string } }) {
  const about = await prisma.aboutContent.findUnique({ where: { id: "about" } });

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">About Page</h1>
      {searchParams.saved && <p className="mb-6 bg-green-50 px-4 py-2 text-sm text-green-800">Saved.</p>}
      <form action={saveAbout} className="max-w-xl space-y-5">
        <div>
          <label className="mb-1 block text-xs text-black/50">About Image</label>
          <ImageUploader name="images" initial={about?.imageUrl ? [{ url: about.imageUrl, alt: "About" }] : []} />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Heading</label>
          <input name="heading" defaultValue={about?.heading} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Paragraph 1</label>
          <textarea name="paragraph1" defaultValue={about?.paragraph1} required className="min-h-[90px] w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Paragraph 2</label>
          <textarea name="paragraph2" defaultValue={about?.paragraph2} required className="min-h-[90px] w-full border border-black/15 px-3 py-2" />
        </div>
        <button className="border border-ink bg-ink px-8 py-3 text-sm text-paper">Save Changes</button>
      </form>
    </div>
  );
}
