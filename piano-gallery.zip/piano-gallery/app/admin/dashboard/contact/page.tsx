import { prisma } from "@/lib/prisma";
import { saveContact } from "../actions";

export default async function AdminContactPage({ searchParams }: { searchParams: { saved?: string } }) {
  const contact = await prisma.contactInfo.findUnique({ where: { id: "contact" } });

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Contact Info</h1>
      {searchParams.saved && <p className="mb-6 bg-green-50 px-4 py-2 text-sm text-green-800">Saved.</p>}
      <form action={saveContact} className="max-w-xl space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-xs text-black/50">Phone</label>
            <input name="phone" defaultValue={contact?.phone} required className="w-full border border-black/15 px-3 py-2" />
          </div>
          <div>
            <label className="mb-1 block text-xs text-black/50">Email</label>
            <input name="email" defaultValue={contact?.email} required className="w-full border border-black/15 px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Address</label>
          <input name="address" defaultValue={contact?.address} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Hours</label>
          <input name="hours" defaultValue={contact?.hours} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-xs text-black/50">Instagram URL</label>
            <input name="instagram" defaultValue={contact?.instagram ?? ""} className="w-full border border-black/15 px-3 py-2" />
          </div>
          <div>
            <label className="mb-1 block text-xs text-black/50">Facebook URL</label>
            <input name="facebook" defaultValue={contact?.facebook ?? ""} className="w-full border border-black/15 px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Google Maps Embed URL (optional)</label>
          <input name="mapEmbedUrl" defaultValue={contact?.mapEmbedUrl ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
        <button className="border border-ink bg-ink px-8 py-3 text-sm text-paper">Save Changes</button>
      </form>
    </div>
  );
}
