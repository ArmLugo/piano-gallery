import { prisma } from "@/lib/prisma";
import { saveNavItem, deleteNavItem } from "../actions";

export default async function AdminNavigationPage({ searchParams }: { searchParams: { saved?: string } }) {
  const items = await prisma.navItem.findMany({ orderBy: { order: "asc" } });

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Navigation</h1>
      {searchParams.saved && <p className="mb-6 bg-green-50 px-4 py-2 text-sm text-green-800">Saved.</p>}

      <div className="mb-10 space-y-4">
        {items.map((item) => (
          <form key={item.id} action={saveNavItem} className="flex items-end gap-3 border border-black/10 p-4">
            <input type="hidden" name="id" value={item.id} />
            <div className="w-20">
              <label className="mb-1 block text-xs text-black/50">Order</label>
              <input name="order" type="number" defaultValue={item.order} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <div className="w-48">
              <label className="mb-1 block text-xs text-black/50">Label</label>
              <input name="label" defaultValue={item.label} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <div className="flex-1">
              <label className="mb-1 block text-xs text-black/50">Link (href)</label>
              <input name="href" defaultValue={item.href} className="w-full border border-black/15 px-2 py-1.5" />
            </div>
            <button className="border border-ink px-4 py-1.5 text-sm">Save</button>
          </form>
        ))}
      </div>

      <div className="flex flex-wrap gap-3">
        {items.map((item) => (
          <form key={item.id} action={deleteNavItem}>
            <input type="hidden" name="id" value={item.id} />
            <button className="text-xs text-red-700 underline">Delete "{item.label}"</button>
          </form>
        ))}
      </div>

      <h2 className="mb-4 mt-10 font-serif text-xl">Add Menu Item</h2>
      <form action={saveNavItem} className="flex items-end gap-3 border border-black/10 p-4">
        <div className="w-20">
          <label className="mb-1 block text-xs text-black/50">Order</label>
          <input name="order" type="number" defaultValue={items.length} className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <div className="w-48">
          <label className="mb-1 block text-xs text-black/50">Label</label>
          <input name="label" required className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <div className="flex-1">
          <label className="mb-1 block text-xs text-black/50">Link (href)</label>
          <input name="href" required placeholder="/pianos" className="w-full border border-black/15 px-2 py-1.5" />
        </div>
        <button className="border border-ink bg-ink px-4 py-1.5 text-sm text-paper">Add</button>
      </form>
    </div>
  );
}
