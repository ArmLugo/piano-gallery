import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import ProductForm from "@/components/ProductForm";
import { saveProduct } from "../../actions";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { images: { orderBy: { order: "asc" } } }
  });
  if (!product) notFound();

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Edit {product.brand} {product.model}</h1>
      <ProductForm action={saveProduct} product={product} />
    </div>
  );
}
