import ProductForm from "@/components/ProductForm";
import { saveProduct } from "../../actions";

export default function NewProductPage() {
  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Add New Piano</h1>
      <ProductForm action={saveProduct} />
    </div>
  );
}
