import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { deleteProduct } from "../actions";

export default async function AdminProductsPage() {
  const products = await prisma.product.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <div>
      <div className="mb-8 flex items-center justify-between">
        <h1 className="font-serif text-3xl">Products</h1>
        <Link href="/admin/dashboard/products/new" className="border border-ink px-5 py-2.5 text-sm">
          + Add New Piano
        </Link>
      </div>
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-black/10 text-left text-black/50">
            <th className="py-3">Brand / Model</th>
            <th>Category</th>
            <th>Price</th>
            <th>Availability</th>
            <th>Featured</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id} className="border-b border-black/5">
              <td className="py-3">{p.brand} {p.model}</td>
              <td>{p.category}</td>
              <td>{p.price}</td>
              <td>{p.availability}</td>
              <td>{p.featured ? "Yes" : "—"}</td>
              <td className="flex gap-4 py-3">
                <Link href={`/admin/dashboard/products/${p.id}`} className="underline">Edit</Link>
                <form action={deleteProduct}>
                  <input type="hidden" name="id" value={p.id} />
                  <button className="text-red-700 underline">Delete</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
