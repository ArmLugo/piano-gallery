import { prisma } from "@/lib/prisma";

export default async function AdminOverviewPage() {
  const [productCount, messageCount] = await Promise.all([
    prisma.product.count(),
    prisma.contactMessage.count()
  ]);

  return (
    <div>
      <h1 className="mb-8 font-serif text-3xl">Overview</h1>
      <div className="flex gap-6">
        <div className="border border-black/10 px-8 py-6">
          <div className="text-3xl font-serif">{productCount}</div>
          <div className="text-sm text-black/50">Pianos listed</div>
        </div>
        <div className="border border-black/10 px-8 py-6">
          <div className="text-3xl font-serif">{messageCount}</div>
          <div className="text-sm text-black/50">Contact inquiries</div>
        </div>
      </div>
    </div>
  );
}
