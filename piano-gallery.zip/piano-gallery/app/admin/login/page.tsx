"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await signIn("credentials", { redirect: false, email, password });
    setLoading(false);
    if (res?.error) {
      setError("Incorrect email or password.");
      return;
    }
    router.push("/admin/dashboard");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-ivory px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm border border-black/10 bg-paper p-10">
        <h1 className="mb-1 font-serif text-2xl">Piano Gallery Admin</h1>
        <p className="mb-6 text-sm text-black/50">Log in to manage the website.</p>
        {error && <p className="mb-4 bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
        <label className="mb-1 block text-xs text-black/50">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mb-4 w-full border border-black/15 px-3 py-2.5"
        />
        <label className="mb-1 block text-xs text-black/50">Password</label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-6 w-full border border-black/15 px-3 py-2.5"
        />
        <button
          disabled={loading}
          className="w-full border border-ink bg-ink py-3 text-sm text-paper disabled:opacity-50"
        >
          {loading ? "Logging in…" : "Log In"}
        </button>
      </form>
    </div>
  );
}
