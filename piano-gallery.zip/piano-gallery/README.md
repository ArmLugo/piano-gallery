# Piano Gallery

A production-ready website + CMS for a premium piano showroom, built with
Next.js 14 (App Router), TypeScript, Tailwind CSS, Prisma + PostgreSQL,
NextAuth, and Vercel Blob for image storage.

## Stack

- **Framework:** Next.js 14 (App Router, Server Components, Server Actions)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Database:** PostgreSQL via Prisma ORM
- **Auth:** NextAuth (Credentials provider — single admin account via env vars)
- **Image storage:** Vercel Blob
- **Hosting:** Vercel

## Project structure

```
app/                    Public pages + admin dashboard (App Router)
  page.tsx              Home
  pianos/                Catalog + [slug] detail page
  grand-pianos/          Grand piano catalog
  about/  services/  contact/
  admin/login/            Admin login
  admin/dashboard/        Protected CMS (products, hero, about, services, contact, nav)
  api/auth/  api/upload/  NextAuth + image upload routes
components/            Header, Footer, ProductCard, ImageUploader, AdminSidebar, ProductForm
lib/                   Prisma client, NextAuth config, helpers
prisma/                schema.prisma + seed.ts
```

Every piece of visible content (hero text/image, about copy, services,
contact info, navigation labels, and all products with multiple photos each)
lives in the database and is edited from `/admin/dashboard` — nothing is
hard-coded in components.

---

## 1. Local setup

```bash
npm install
cp .env.example .env        # fill in the values (see below)
npx prisma db push          # create tables from schema.prisma
npm run db:seed             # sample pianos + starter content
npm run dev                 # http://localhost:3000
```

Generate your admin password hash:

```bash
node -e "console.log(require('bcryptjs').hashSync('your-password', 10))"
```

Put that hash in `ADMIN_PASSWORD_HASH`, and your email in `ADMIN_EMAIL`.
Log in at `/admin/login`.

---

## 2. Deploying to Vercel — exact steps

### Step 1 — Push the code to a Git repo

```bash
git init
git add .
git commit -m "Piano Gallery"
git branch -M main
git remote add origin <your-empty-github-repo-url>
git push -u origin main
```

### Step 2 — Import the project into Vercel

1. Go to https://vercel.com/new
2. Import the GitHub repo you just pushed.
3. Framework Preset: Vercel auto-detects **Next.js** — leave the default
   build command (`npm run build`, which already runs `prisma generate`
   via the `postinstall`/`build` scripts in `package.json`).
4. **Don't click Deploy yet** — add the database and blob store first (next
   two steps), since the app needs `DATABASE_URL` and `BLOB_READ_WRITE_TOKEN`
   to build successfully.

### Step 3 — Add a Postgres database

1. In your Vercel project → **Storage** tab → **Create Database** → **Postgres**
   (Vercel Postgres, powered by Neon).
2. Accept the defaults and connect it to your project. Vercel automatically
   injects `DATABASE_URL` and (for Neon) `DIRECT_URL`/`POSTGRES_URL_NON_POOLING`
   into your project's environment variables — no manual copy/paste needed.
3. If your provider only gives you one pooled URL, set `DIRECT_URL` to the
   same value as `DATABASE_URL` in the next step (Prisma migrations just need
   *a* working connection string).

*(Alternative: create a free Postgres database on [neon.tech](https://neon.tech)
or [supabase.com](https://supabase.com) instead, and paste the connection
string into `DATABASE_URL` / `DIRECT_URL` manually in Step 5.)*

### Step 4 — Add a Blob store (for image uploads)

1. Same **Storage** tab → **Create Database** → **Blob**.
2. Connect it to your project. Vercel injects `BLOB_READ_WRITE_TOKEN`
   automatically.

### Step 5 — Set the remaining environment variables

In your Vercel project → **Settings → Environment Variables**, add (for
Production, Preview, and Development environments):

| Variable | Value |
|---|---|
| `NEXTAUTH_SECRET` | Output of `openssl rand -base64 32` |
| `NEXTAUTH_URL` | Your deployed URL, e.g. `https://piano-gallery.vercel.app` (update after your first deploy gives you the real domain) |
| `ADMIN_EMAIL` | The email you'll log into `/admin/login` with |
| `ADMIN_PASSWORD_HASH` | Output of `node -e "console.log(require('bcryptjs').hashSync('your-password', 10))"` |

`DATABASE_URL`, `DIRECT_URL`, and `BLOB_READ_WRITE_TOKEN` should already be
present from Steps 3–4 — verify they're there.

### Step 6 — Deploy

Click **Deploy**. Vercel will run `npm install` → `prisma generate` →
`next build`.

### Step 7 — Create the database tables and seed sample content

The build does **not** run migrations automatically (that's deliberate — you
don't want schema changes applying themselves on every deploy). After the
first successful deploy, run this once from your local machine, pointed at
the production database:

```bash
# Pull the real DATABASE_URL/DIRECT_URL Vercel generated, into a local file
npx vercel env pull .env.production.local

# Push the schema and seed starter content
npx dotenv -e .env.production.local -- npx prisma db push
npx dotenv -e .env.production.local -- npx tsx prisma/seed.ts
```

(No `dotenv-cli` installed? `npm i -D dotenv-cli` first, or just temporarily
copy the production `DATABASE_URL`/`DIRECT_URL` into your local `.env` and
run `npx prisma db push` / `npm run db:seed` directly.)

### Step 8 — Update NEXTAUTH_URL and redeploy

Once you have your real Vercel URL (or a custom domain attached under
**Settings → Domains**), set `NEXTAUTH_URL` to that exact URL and redeploy
(**Deployments → ⋯ → Redeploy**) so login sessions and metadata URLs are
correct.

### Step 9 — Verify

1. Visit your deployed URL — the public site should load with seeded content.
2. Go to `/admin/login`, sign in with `ADMIN_EMAIL` / your chosen password.
3. Add a new piano, upload photos, edit the homepage hero text and image,
   edit contact info, save, then reload the public site and confirm the
   changes appear.

---

## Notes for future changes

- **Schema changes:** edit `prisma/schema.prisma`, then run
  `npx prisma db push` (quick, no migration history) or
  `npx prisma migrate dev` locally to generate a migration, commit the
  migration folder, and run `npm run db:migrate` (`prisma migrate deploy`)
  against production.
- **Adding an admin user / multiple admins:** the current setup is
  single-owner by design (one email/password pair in env vars). For multiple
  admin accounts, add an `AdminUser` table and swap the `authorize()` check
  in `lib/auth.ts` to query it instead.
- **Contact form submissions** are stored in the `ContactMessage` table
  (viewable via `npx prisma studio`). Wire up an email notification (e.g.
  Resend) in `app/contact/actions.ts` if you want live alerts.
