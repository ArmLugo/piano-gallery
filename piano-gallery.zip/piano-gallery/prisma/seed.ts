import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  await prisma.heroContent.upsert({
    where: { id: "hero" },
    update: {},
    create: {
      id: "hero",
      title: "The Art of Music",
      subtitle:
        "Discover carefully selected pianos and grand pianos created for musicians who appreciate exceptional sound, craftsmanship and timeless design.",
      imageUrl: null
    }
  });

  await prisma.aboutContent.upsert({
    where: { id: "about" },
    update: {},
    create: {
      id: "about",
      heading: "About Piano Gallery",
      paragraph1:
        "For over two decades we have curated instruments for musicians, teachers and collectors — every piano hand-selected, inspected and prepared before it reaches our floor.",
      paragraph2:
        "Our consultants guide each client through selection, delivery and long-term care, with warranty and tuning support built into every purchase.",
      imageUrl: null
    }
  });

  await prisma.contactInfo.upsert({
    where: { id: "contact" },
    update: {},
    create: {
      id: "contact",
      phone: "+1 (212) 555-0199",
      email: "hello@pianogallery.com",
      address: "128 Madison Avenue, New York, NY",
      hours: "Tue–Sat, 10:00–18:00",
      instagram: "https://instagram.com/pianogallery",
      facebook: "https://facebook.com/pianogallery"
    }
  });

  const services = [
    { title: "Piano Sales", description: "Professional selection of upright pianos and grand pianos for every space and budget.", order: 0 },
    { title: "Piano Delivery", description: "Safe, insured transportation handled by specialist piano movers.", order: 1 },
    { title: "Piano Tuning", description: "Ongoing tuning and maintenance from certified technicians.", order: 2 },
    { title: "Warranty", description: "Extended warranty and after-sales support on every instrument sold.", order: 3 },
    { title: "Consultation", description: "One-on-one guidance to match an instrument to your needs and room.", order: 4 }
  ];
  for (const s of services) {
    const existing = await prisma.service.findFirst({ where: { title: s.title } });
    if (!existing) await prisma.service.create({ data: s });
  }

  const navItems = [
    { label: "Home", href: "/", order: 0 },
    { label: "Pianos", href: "/pianos", order: 1 },
    { label: "Grand Pianos", href: "/grand-pianos", order: 2 },
    { label: "About Us", href: "/about", order: 3 },
    { label: "Services", href: "/services", order: 4 },
    { label: "Contact", href: "/contact", order: 5 }
  ];
  for (const n of navItems) {
    const existing = await prisma.navItem.findFirst({ where: { label: n.label } });
    if (!existing) await prisma.navItem.create({ data: n });
  }

  const products = [
    {
      slug: "yamaha-c3",
      brand: "Yamaha",
      model: "C3",
      category: "grand",
      price: "$28,500",
      priceValue: 28500,
      year: 2019,
      dimensions: "6'1\" (186 cm)",
      finish: "Polished Ebony",
      color: "Black",
      condition: "Excellent (pre-owned)",
      availability: "In Stock",
      description: "A conservatory favorite prized for its clarity and even touch across the register.",
      specs: JSON.stringify({ Action: "Yamaha grand action", Soundboard: "Solid spruce", Keys: "88, ivorite" }),
      featured: true
    },
    {
      slug: "yamaha-c5",
      brand: "Yamaha",
      model: "C5",
      category: "grand",
      price: "$34,900",
      priceValue: 34900,
      year: 2021,
      dimensions: "6'7\" (200 cm)",
      finish: "Polished Ebony",
      color: "Black",
      condition: "New",
      availability: "In Stock",
      description: "Richer bass and greater projection, suited to larger rooms and serious study.",
      specs: JSON.stringify({ Action: "Yamaha grand action", Soundboard: "Solid spruce", Keys: "88, ivorite" }),
      featured: true
    },
    {
      slug: "kawai-ca-series",
      brand: "Kawai",
      model: "CA Series",
      category: "digital",
      price: "$4,200",
      priceValue: 4200,
      year: 2023,
      dimensions: "58\" W x 18\" D",
      finish: "Satin Black",
      color: "Black",
      condition: "New",
      availability: "In Stock",
      description: "Hybrid action and sampled grand tone for players without room for an acoustic.",
      specs: JSON.stringify({ Action: "Grand Feel wooden-key", Speakers: "4-way", Polyphony: "256-note" }),
      featured: true
    },
    {
      slug: "kawai-gx-2",
      brand: "Kawai",
      model: "GX-2",
      category: "grand",
      price: "$31,200",
      priceValue: 31200,
      year: 2020,
      dimensions: "5'11\" (180 cm)",
      finish: "Polished Ebony",
      color: "Black",
      condition: "Excellent (pre-owned)",
      availability: "In Stock",
      description: "Warm, singing tone with the refined Millennium III action.",
      specs: JSON.stringify({ Action: "Millennium III", Soundboard: "Solid spruce", Keys: "88" }),
      featured: true
    },
    {
      slug: "august-forster-170",
      brand: "August Förster",
      model: "170",
      category: "grand",
      price: "Contact for Price",
      priceValue: null,
      year: 2018,
      dimensions: "5'7\" (170 cm)",
      finish: "Satin Walnut",
      color: "Walnut",
      condition: "Excellent (pre-owned)",
      availability: "On Order",
      description: "Hand-built in Germany with a distinctive, colourful tonal palette.",
      specs: JSON.stringify({ Action: "Renner action", Soundboard: "Solid spruce", Keys: "88" }),
      featured: true
    },
    {
      slug: "ritmuller-up110r",
      brand: "Ritmüller",
      model: "UP110R",
      category: "upright",
      price: "$6,800",
      priceValue: 6800,
      year: 2022,
      dimensions: "43\" (110 cm)",
      finish: "Polished Mahogany",
      color: "Mahogany",
      condition: "New",
      availability: "In Stock",
      description: "An accessible entry point into the Ritmüller design lineage.",
      specs: JSON.stringify({ Action: "Renner-designed vertical action", Soundboard: "Solid spruce", Keys: "88" }),
      featured: true
    }
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {},
      create: p
    });
  }

  console.log("Seed complete.");
  console.log(
    "Admin login — set ADMIN_EMAIL and ADMIN_PASSWORD_HASH in your env. Example hash for 'change-me-now':",
    bcrypt.hashSync("change-me-now", 10)
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
