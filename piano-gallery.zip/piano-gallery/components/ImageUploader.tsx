"use client";

import { useState } from "react";

type UploadedImage = { url: string; alt: string };

export default function ImageUploader({
  name,
  initial = []
}: {
  name: string;
  initial?: UploadedImage[];
}) {
  const [images, setImages] = useState<UploadedImage[]>(initial);
  const [uploading, setUploading] = useState(false);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      const uploaded: UploadedImage[] = [];
      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/upload", { method: "POST", body: formData });
        if (!res.ok) throw new Error("Upload failed");
        const data = await res.json();
        uploaded.push({ url: data.url, alt: file.name });
      }
      setImages((prev) => [...prev, ...uploaded]);
    } catch (err) {
      alert("One or more images failed to upload. Please try again.");
    } finally {
      setUploading(false);
    }
  }

  function removeImage(url: string) {
    setImages((prev) => prev.filter((img) => img.url !== url));
  }

  return (
    <div className="space-y-3">
      <input type="hidden" name={name} value={JSON.stringify(images)} />
      <div className="flex flex-wrap gap-3">
        {images.map((img) => (
          <div key={img.url} className="relative h-24 w-24 border border-black/10 bg-ivory">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img.url} alt={img.alt} className="h-full w-full object-cover" />
            <button
              type="button"
              onClick={() => removeImage(img.url)}
              className="absolute right-0 top-0 bg-ink px-1.5 py-0.5 text-xs text-paper"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
      <input
        type="file"
        accept="image/*"
        multiple
        disabled={uploading}
        onChange={(e) => handleFiles(e.target.files)}
        className="text-sm"
      />
      {uploading && <p className="text-xs text-black/50">Uploading…</p>}
    </div>
  );
}
