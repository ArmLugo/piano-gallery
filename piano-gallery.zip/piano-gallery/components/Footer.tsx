import { prisma } from "@/lib/prisma";

export default async function Footer() {
  const contact = await prisma.contactInfo.findUnique({ where: { id: "contact" } });

  return (
    <footer className="bg-ink py-10 text-sm text-[#B9B2A1]">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-8">
        <span>&copy; {new Date().getFullYear()} Piano Gallery</span>
        <div className="flex gap-4">
          {contact?.instagram && <a href={contact.instagram}>Instagram</a>}
          {contact?.facebook && <a href={contact.facebook}>Facebook</a>}
        </div>
      </div>
    </footer>
  );
}
