"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import clsx from "clsx";

const links = [
  { href: "/admin/dashboard", label: "Overview" },
  { href: "/admin/dashboard/products", label: "Products" },
  { href: "/admin/dashboard/hero", label: "Homepage Hero" },
  { href: "/admin/dashboard/about", label: "About Page" },
  { href: "/admin/dashboard/services", label: "Services" },
  { href: "/admin/dashboard/contact", label: "Contact Info" },
  { href: "/admin/dashboard/navigation", label: "Navigation" }
];

export default function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-56 shrink-0 border-r border-black/10 p-6">
      <div className="mb-8 font-serif text-xl">Admin</div>
      <nav className="flex flex-col gap-1 text-sm">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={clsx(
              "px-3 py-2",
              pathname === link.href ? "bg-ink text-paper" : "hover:bg-ivory"
            )}
          >
            {link.label}
          </Link>
        ))}
      </nav>
      <button
        onClick={() => signOut({ callbackUrl: "/" })}
        className="mt-8 px-3 py-2 text-sm text-black/50 underline"
      >
        Log out
      </button>
    </aside>
  );
}
