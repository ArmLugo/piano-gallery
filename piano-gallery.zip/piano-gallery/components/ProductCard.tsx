import Link from "next/link";
import Image from "next/image";
import type { ProductWithImages } from "@/types";

export default function ProductCard({ product }: { product: ProductWithImages }) {
  const image = product.images[0];

  return (
    <div className="flex flex-col gap-3 bg-paper p-8">
      <div className="relative aspect-[5/4] bg-ivory">
        {image ? (
          <Image src={image.url} alt={image.alt ?? product.model} fill className="object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center text-xs text-black/30">No photo</div>
        )}
      </div>
      <div className="text-xs tracking-wider text-bronze">{product.brand.toUpperCase()}</div>
      <h3 className="font-serif text-2xl">{product.model}</h3>
      <div className="text-sm text-black/50">
        {product.category === "grand" ? "Grand Piano" : product.category === "upright" ? "Upright Piano" : "Digital Piano"}
        {product.dimensions ? ` · ${product.dimensions}` : ""}
      </div>
      <p className="flex-grow text-sm text-black/70">{product.description}</p>
      <div className="mt-1 flex items-center justify-between border-t border-black/10 pt-4">
        <span className="text-sm">{product.price}</span>
        <Link href={`/pianos/${product.slug}`} className="border-b border-ink text-sm">
          View Details
        </Link>
      </div>
    </div>
  );
}
