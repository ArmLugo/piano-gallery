import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function Header() {
  const navItems = await prisma.navItem.findMany({ orderBy: { order: "asc" } });

  return (
    <header className="sticky top-0 z-50 border-b border-black/10 bg-paper/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-8 py-6">
        <Link href="/" className="font-serif text-2xl tracking-wide">
          <span className="font-semibold">PIANO</span> GALLERY
        </Link>
        <nav className="hidden gap-9 text-sm md:flex">
          {navItems.map((item) => (
            <Link key={item.id} href={item.href} className="hover:text-bronze">
              {item.label}
            </Link>
          ))}
        </nav>
        <Link
          href="/contact"
          className="border border-ink px-5 py-2.5 text-sm tracking-wide transition hover:bg-ink hover:text-paper"
        >
          Contact Us
        </Link>
      </div>
    </header>
  );
}
