"use client";

import ImageUploader from "@/components/ImageUploader";
import type { ProductWithImages } from "@/types";
import { formatSpecs } from "@/lib/utils";

export default function ProductForm({
  action,
  product
}: {
  action: (formData: FormData) => void;
  product?: ProductWithImages;
}) {
  const specs = product ? formatSpecs(product.specs) : {};
  const specsText = Object.entries(specs)
    .map(([k, v]) => `${k}: ${v}`)
    .join("\n");

  return (
    <form action={action} className="max-w-2xl space-y-5">
      {product && <input type="hidden" name="id" value={product.id} />}

      <div>
        <label className="mb-1 block text-xs text-black/50">Photos</label>
        <ImageUploader
          name="images"
          initial={product?.images.map((i) => ({ url: i.url, alt: i.alt ?? "" })) ?? []}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1 block text-xs text-black/50">Brand</label>
          <input name="brand" defaultValue={product?.brand} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Model</label>
          <input name="model" defaultValue={product?.model} required className="w-full border border-black/15 px-3 py-2" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="mb-1 block text-xs text-black/50">Category</label>
          <select name="category" defaultValue={product?.category ?? "grand"} className="w-full border border-black/15 px-3 py-2">
            <option value="grand">Grand Piano</option>
            <option value="upright">Upright Piano</option>
            <option value="digital">Digital Piano</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Availability</label>
          <select name="availability" defaultValue={product?.availability ?? "In Stock"} className="w-full border border-black/15 px-3 py-2">
            <option>In Stock</option>
            <option>On Order</option>
            <option>Sold</option>
          </select>
        </div>
        <div className="flex items-end gap-2 pb-2.5">
          <input type="checkbox" name="featured" id="featured" defaultChecked={product?.featured} />
          <label htmlFor="featured" className="text-sm">Featured on homepage</label>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1 block text-xs text-black/50">Display Price (e.g. "$28,500" or "Contact for Price")</label>
          <input name="price" defaultValue={product?.price} required className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Numeric Price (for filtering — leave blank if "Contact for Price")</label>
          <input name="priceValue" type="number" defaultValue={product?.priceValue ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="mb-1 block text-xs text-black/50">Year</label>
          <input name="year" type="number" defaultValue={product?.year ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Dimensions</label>
          <input name="dimensions" defaultValue={product?.dimensions ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Finish</label>
          <input name="finish" defaultValue={product?.finish ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-xs text-black/50">Color</label>
          <input name="color" defaultValue={product?.color ?? ""} className="w-full border border-black/15 px-3 py-2" />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-xs text-black/50">Condition</label>
        <input name="condition" defaultValue={product?.condition ?? ""} className="w-full border border-black/15 px-3 py-2" />
      </div>

      <div>
        <label className="mb-1 block text-xs text-black/50">Description</label>
        <textarea name="description" defaultValue={product?.description} required className="min-h-[90px] w-full border border-black/15 px-3 py-2" />
      </div>

      <div>
        <label className="mb-1 block text-xs text-black/50">Technical specs (one per line, "Key: Value")</label>
        <textarea
          name="specsText"
          defaultValue={specsText}
          onChange={(e) => {
            const form = e.currentTarget.closest("form");
            const hidden = form?.querySelector<HTMLInputElement>('input[name="specs"]');
            if (!hidden) return;
            const obj: Record<string, string> = {};
            e.currentTarget.value.split("\n").forEach((line) => {
              const [k, ...rest] = line.split(":");
              if (k && rest.length) obj[k.trim()] = rest.join(":").trim();
            });
            hidden.value = JSON.stringify(obj);
          }}
          className="min-h-[80px] w-full border border-black/15 px-3 py-2"
          placeholder={"Action: Yamaha grand action\nSoundboard: Solid spruce"}
        />
        <input type="hidden" name="specs" defaultValue={product?.specs ?? "{}"} />
      </div>

      <button className="border border-ink bg-ink px-8 py-3 text-sm text-paper">Save Piano</button>
    </form>
  );
}
