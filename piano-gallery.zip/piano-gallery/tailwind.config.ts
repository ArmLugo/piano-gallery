import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ivory: "#F3EEE4",
        paper: "#FAF7F1",
        ink: "#17140F",
        charcoal: "#2B271F",
        bronze: "#9C7A4C",
        "bronze-soft": "#C4A876"
      },
      fontFamily: {
        serif: ["var(--font-display)", "serif"],
        sans: ["var(--font-body)", "sans-serif"]
      }
    }
  },
  plugins: []
};

export default config;
